# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["MCPServerToolCallContent"]


class MCPServerToolCallContent(BaseModel):
    """MCPServer tool call content."""

    id: str
    """Required. A unique ID for this specific tool call."""

    arguments: Dict[str, object]
    """Required. The JSON object of arguments for the function."""

    name: str
    """Required. The name of the tool which was called."""

    server_name: str
    """Required. The name of the used MCP server."""

    type: Literal["mcp_server_tool_call"]

    signature: Optional[str] = None
    """A signature hash for backend validation."""
